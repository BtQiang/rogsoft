#!/bin/sh
source /koolshare/scripts/base.sh

rm -rf /koolshare/bin/file*.png
rm -rf /koolshare/bin/zerotier*.png
rm -rf /koolshare/lib/libmagic*
rm -rf /koolshare/lib/libnatpmp*
rm -rf /koolshare/lib/libminiupnpc*
rm -rf /koolshare/share/share/misc/magic
rm -rf /koolshare/res/icon-zerotier.png
rm -rf /koolshare/init.d/*zerotier.sh
rm -rf /koolshare/scripts/zerotier_*.sh
rm -rf /koolshare/webs/Module_zerotier.asp
rm -rf /tmp/zerotier*
