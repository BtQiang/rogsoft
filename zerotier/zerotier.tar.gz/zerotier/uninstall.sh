#!/bin/sh
source /koolshare/scripts/base.sh

rm -rf /koolshare/res/icon-zerotier.png
rm -rf /koolshare/init.d/*zerotier.sh
rm -rf /koolshare/scripts/zerotier_*.sh
rm -rf /koolshare/webs/Module_zerotier.asp
rm -rf /tmp/zerotier*

