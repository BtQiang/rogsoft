#!/bin/sh

rm /koolshare/bin/vlmcsd
rm /koolshare/res/icon-kms.png
rm /koolshare/scripts/kms*
rm /koolshare/webs/Module_kms.asp