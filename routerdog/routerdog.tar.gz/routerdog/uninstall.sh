#!/bin/sh
source /koolshare/scripts/base.sh

rm -rf /koolshare/res/icon-routerdog.png
rm -rf /koolshare/scripts/routerdog.sh
rm -rf /koolshare/webs/Module_routerdog.asp
rm -rf /tmp/routerdog*

